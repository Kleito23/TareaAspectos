package ec.edu.espol.adapter;

public class CajaRegistradora {
    public void procesarPago(double montoEnDolares) {
        System.out.println("Procesando pago de $" + montoEnDolares + " en la caja registradora de Ecuador.");
    }
}
