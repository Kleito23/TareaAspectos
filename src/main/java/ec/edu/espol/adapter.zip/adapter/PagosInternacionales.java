package ec.edu.espol.adapter;

public interface PagosInternacionales {
    void pagoEnUSD(double amount);
    void pagoEnEUR(double amount);
    void pagoEnBtc(double amount);

}
